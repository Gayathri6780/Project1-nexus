const mainContainer = document.getElementById("main-container");
const signupForm = document.getElementById("signup-form");
const loginForm = document.getElementById("login-form");
const dynamicButtonsContainer = document.getElementById("dynamic-buttons");

// Array to store registered usernames and passwords
const registeredUsers = [];

function signup() {
  const username = document.getElementById("signup-username").value;
  const password = document.getElementById("signup-password").value;

  if (username === "" || password === "") {
    alert("Please enter both username and password");
  } else if (isUserRegistered(username, password)) {
    createDynamicButton();
    showLoginForm();
    
    alert("User already exists. Please login.");
  } else {
    registeredUsers.push({ username, password });
    alert("Signup successful");
    showLoginForm();
  }
}

function showLoginForm() {
  loginForm.style.display = "block";
  dynamicButtonsContainer.style.display = "block";
  signupForm.style.display = "none";
}

function showSignupForm() {
  loginForm.style.display = "none";
  dynamicButtonsContainer.style.display = "none";
  signupForm.style.display = "block";
  createDynamicButton();
}

function login() {
  const username = document.getElementById("login-username").value;
  const password = document.getElementById("login-password").value;

  if (username === "" || password === "") {
    alert("Please enter both username and password");
  } else if (isUserRegistered(username, password)) {
    alert("Login Successful");
    showSignupForm();
  } else {
    alert("Username or Password is incorrect");
  }
}

function isUserRegistered(username, password) {
  return registeredUsers.some(user => user.username === username && user.password === password);
}

function createDynamicButton() {
  const loginButton = document.createElement("button");
  const error = document.createElement("p");
  error.textContent = "Already have an account?";
  error.className = "para";
  loginButton.textContent = "Login";
  loginButton.className = "button1";
  loginButton.onclick = function () {
    showLoginForm();
  };

  // Clear existing content and append new content
  dynamicButtonsContainer.innerHTML = "";
  dynamicButtonsContainer.appendChild(error);
  dynamicButtonsContainer.appendChild(loginButton);
}